dotBeats S02 — assembly guide and complete PCB mounting

Open assembly-guide.html for the complete ten-step instructions and hardware checklist.
The local interactive guide runs at http://127.0.0.1:5183/ while its server is running.
Restart: cd site && npm run dev -- --port 5183

PRINT
1 base-S02.stl (replaces S01 base; includes three underside nut pockets)
1 lid-C01.stl
6 cap-C01.stl + 6 plug-C01.stl
2 side-cap-print-2.stl + 2 side-retainer-print-2.stl
3 pcb-centering-bush-print-3.stl
The side-fit-coupon.stl is an optional single-side-button fit test.

NEW PCB HARDWARE
3 M2.5 x 6 mm machine screws, head <= 4.5 mm diameter x 1.7 mm high
3 M2.5 nuts: 5 mm across flats, 2 mm thick
3 insulating washers: OD7 / ID2.7 x 0.5 mm thick
3 printed centering bushes: OD4.8 / ID2.8 x 1.5 mm high
Nut pockets: AF5.3 x 2.2 mm deep, accessible from the underside.
PCB bottom stays at z4.2 mm; total PCB thickness approximately 1.60 mm.
Do not use the enclosure's 8 mm screws for the PCB.

OTHER HARDWARE
Side retainers: 4 M2 x 6 mm plastic self-tapping screws, verify actual pilot fit.
Enclosure: 4 M2.5 x 8 mm screws + 4 M2.5 inserts OD4.6 x 4 mm.
Reuse the existing PCB/ESP, battery and front-button assemblies.

Coordinates: STLs use the C01 lid-underside datum, in millimetres. Add
(1.059492769, 3, 24) to recover original global case coordinates.
Bush and side-cap/retainer printing files are independently bed-aligned.
GLB is in metres and preserves assembled positions.
Screw and insert threads are omitted; geometry is an assembly envelope.

Validated digitally: watertight single base; PCB hole centres/radii; nut-pocket
clearance; no new PCB-fastener/component collisions. See checks.json.
A physical fit trial, wire routing, fastener torque and button return testing remain required.
The guide does not specify electrical pinout; follow the actual PCB circuit.
Original S01 files are preserved. Published S02 guide: https://evannnx.github.io/dotbeats-case-studio/
