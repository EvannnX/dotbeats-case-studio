"""Rear screw access; heat-set inserts in lid bosses. Millimetres."""
import cadquery as cq

def screw_layout(p):
 return dict(z=p['height']-p['lid'],points=[(a*(p['width']/2-7.5),b*(p['length']/2-10))for a in [-1,1]for b in [-1,1]],pocket_depth=p['insertL']+1)
def add_screw_fit(base,lid,p):
 q=screw_layout(p)
 def post(d,h,x,y,z):return cq.Workplane('XY',origin=(x,y,z)).circle(d/2).extrude(h)
 def rounded(w,l,d,r,z):return cq.Workplane('XY',origin=(0,0,z)).box(w,l,d,centered=(True,True,False)).edges('|Z').fillet(r)
 w=p['width']-2*(p['wall']+p['fitClear']);l=p['length']-2*(p['wall']+p['fitClear']);r=p['radius']-p['wall']-p['fitClear'];z=q['z']
 lip=rounded(w,l,p['lipDepth']+.05,r,z-p['lipDepth']).cut(rounded(w-2.4,l-2.4,p['lipDepth']+.3,r-1.2,z-p['lipDepth']-.1))
 lid=lid.union(lip)
 for x,y in q['points']:
  base=base.union(post(p['bossD'],p['supportH']-p['floor']+.1,x,y,p['floor']-.1)).cut(post(p['clearD'],p['supportH']+2,x,y,-1)).cut(post(p['headD'],p['headDepth']+1,x,y,-1))
  lid=lid.union(post(p['bossD'],z-p['supportH']+.05,x,y,p['supportH'])).cut(post(p['insertHole'],q['pocket_depth']+.1,x,y,p['supportH']-.1))
 return base,lid
