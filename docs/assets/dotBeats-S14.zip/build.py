"""S14 analytic CAD rebuild. CadQuery 2.8. Units mm. Mechanical parts only."""
from pathlib import Path
import json,math,shutil
import cadquery as cq
P=Path(__file__).parent;ROOT=P.parent
(P/'parts').mkdir(exist_ok=True)
A=json.loads((P/'assembly-data.json').read_text())
OFF=(1.059492769,3,24)
W,L,H=86.5,140,24

def box(x0,x1,y0,y1,z0,z1):return cq.Workplane().box(x1-x0,y1-y0,z1-z0).translate(((x0+x1)/2,(y0+y1)/2,(z0+z1)/2))
def cyl(r,z,h,x=0,y=0):return cq.Workplane('XY',origin=(x,y,z)).circle(r).extrude(h)
def cx(r,x0,x1,y=0,z=13):return cq.Workplane('YZ',origin=(x0,y,z)).circle(r).extrude(x1-x0)
def rounded(w,l,r,z,h):return cq.Workplane('XY',origin=(0,0,z)).rect(w,l).extrude(h).edges('|Z').fillet(r)
def hexa(af,z,h,x,y):return cq.Workplane('XY',origin=(x,y,z)).polygon(6,af/math.cos(math.pi/6)).extrude(h)
# Established 26 mm shell, PCB datum and battery cradle.
base=rounded(W,L,9,0,21.75).cut(rounded(W-4,L-4,7,2,22.75))
for y in [-40,40]:base=base.cut(cx(6.3,-46.75,-39.75,y))
ep=[OFF[0]+A['esp_local_origin'][0],OFF[1]+A['esp_local_origin'][1],4.2+A['esp_height_above_carrier']]
port=rounded(9.00682486587+1.2,2.16096579007+1.2,1.4,0,6).rotate((0,0,0),(0,1,0),90).rotate((0,0,0),(1,0,0),90).translate((39.25,ep[1]+.06976233844,ep[2]+1.05351562325))
base=base.cut(port)
mounts=[(x+OFF[0],y+OFF[1]) for x,y in A['mount_holes_local']]
for x,y in mounts:base=base.union(cyl(4,1.85,2.35,x,y).cut(cyl(1.4,1.7,2.7,x,y)))
# Battery rests directly on the floor; retain conservative 18.7 x 53.3 envelope.
bz=11.35;by=-58.2
# Continuous lower-half cradle: 0.3 mm radial and axial clearance.
battery_holder=box(-28.6,28.6,-68.2,-46.95,1.9,bz)
battery_holder=battery_holder.cut(cx(9.65,-26.95,26.95,by,bz))
# Open end channels leave room for the existing battery leads.
for x0,x1 in [(-28.7,-26.94),(26.94,28.7)]:
 battery_holder=battery_holder.cut(box(x0,x1,by-3,by+3,8,12))
base=base.union(battery_holder)
corner=[(x,y) for x in [-35.75,35.75] for y in [-60,60]]
for x,y in corner:base=base.union(cyl(5,1.9,6.1,x,y)).cut(cyl(1.45,-1,10,x,y)).cut(cyl(2.5,-1,4.5,x,y))
for x,y in mounts:base=base.cut(hexa(5.3,-.1,2.3,x,y)).cut(cyl(1.4,-.1,4.4,x,y))
# Import only the analytic construction declarations of the S14 side holder.
source=(P/'side_profile.py').read_text()
ns={'cq':cq};exec(source,ns)
side_holder=ns['holder']
for y in [-40,40]:
 base=base.union(side_holder.translate((0,y,0)))
 # Top-entry side cap slot allows assembly after integrating the chair.
 base=base.cut(box(-44,-40.99,y-6.3,y+6.3,13,22))

side_cap=cx(6,-44.85,-41.25).union(cx(7.4,-41.25,-40.05)).union(cx(1.5,-40.05,-38.8))
# Lid and guide sleeves. Centred key grid, original fixed PCB positions retained.
keys=[(x,y) for y in [-22.500045720091,22.500045720091] for x in [-20.000038100076,0,20.000038100076]]
lid=rounded(W,L,9,22,2)
# Lid tongue closes the top-entry slot around the side cap.
for cy in [-40,40]:
 tongue=box(-43.25,-41.25,cy-6.05,cy+6.05,13,22.1).cut(cx(6.3,-44,-40,cy))
 lid=lid.union(tongue)
lip=rounded(81.9,135.4,6.7,19,3.05).cut(rounded(79.5,133,5.5,18.9,3.3));lid=lid.union(lip)
for x,y in corner:lid=lid.union(cyl(5,8,14.05,x,y)).cut(cyl(2,7.9,5.1,x,y))
for x,y in keys:
 sleeve=cyl(8.8,18,4.1,x,y).cut(cyl(6.75,17.9,4.3,x,y)).cut(box(x,x+17.6,y-1.7,y+1.7,17.9,21.3))
 lid=lid.union(sleeve)
for x,y in keys:lid=lid.cut(cyl(6.8,17.9,6.3,x,y)).cut(box(x-.9,x+.9,y-7.6,y-5.95,17.9,24.3))
# Lid stop traps switch from above without loading the actuator or solder tabs.
for cy in [-40,40]:
 lid=lid.union(box(-37.1,-34.4,cy-4.6,cy+4.6,16.5,22.1))

# Simple four-sided lid frame surrounds the unchanged S11 cradle.
for cy in [-40,40]:
 frame=box(-39.6,-28.3,cy-6.6,cy+6.6,16.5,22.1)
 for sign in [-1,1]:
  a,b=sorted([cy+sign*5.5,cy+sign*6.6])
  frame=frame.union(box(-39.6,-28.3,a,b,6.4,22.1))
 frame=frame.union(box(-30.3,-28.3,cy-6.6,cy+6.6,6.4,22.1))
 frame=frame.cut(box(-30.4,-28.2,cy-4.9,cy+4.9,11.3,15.5))
 front=box(-39.6,-38.5,cy-6.6,cy+6.6,10.3,22.1)
 front=front.cut(box(-39.7,-38.4,cy-2.5,cy+2.5,10.2,15.6))
 lid=lid.union(frame).union(front)
# Relief in the inner lid lip clears the side-cap retaining flange during closure.
for cy in [-40,40]:lid=lid.cut(cx(7.65,-41.249,-39.5,cy))
# Front parts in local coordinates with lid underside z=0.
cap=cyl(6.5,-4,9).union(cyl(7.9,2.4,2.6)).cut(cyl(5.25,-4.1,7.9))
cap=cap.cut(box(0,13,-1.2,1.2,-4.1,-1.1)).union(box(-.6,.6,-7.3,-6.25,-2.5,2.4)).union(box(-.6,.6,-5.65,-4.65,-4,-.7))
tip=5.8000508-22+5;bottom=-5.2;seat=-.45
plug=cyl(5.15,bottom,seat-bottom).union(cyl(8,bottom,1.2)).union(cyl(1.5,tip,bottom-tip+.1,-2.690514851012,3.25000127013))
plug=plug.cut(box(3.25,19.25,-1.2,1.2,-5.3,-.35)).cut(box(0,4,-1.5,1.5,-1.65,-.35)).cut(box(-.8,.8,-5.85,-4.45,-4.1,-.25))
bush=cyl(2.4,0,1.5).cut(cyl(1.4,-.1,1.7))
parts={'base-S14':base,'lid-S14':lid,'front-cap-S14':cap,'front-carrier-S14':plug,'side-cap-S14':side_cap,'pcb-centering-bush':bush}
report={'status':'PROTOTYPE: actual switches, motor solder joints and wiring need fit testing','height_mm':24,'battery_body_top_clearance_mm':1.3,'side_switch_top_clearance_mm':.5,'switch_body_side_clearance_mm':.2,'battery_bracket_volume_mm3':battery_holder.val().Volume()};assy=cq.Assembly(name='dotBeats_S14_MECHANICAL')
for name,obj in parts.items():
 obj=obj.clean();parts[name]=obj;s=obj.val();assert s.isValid() and len(s.Solids())==1,(name,len(s.Solids()))
 path=P/'parts'/f'{name}.step';cq.exporters.export(obj,str(path));back=cq.importers.importStep(str(path)).val();assert back.isValid() and len(back.Solids())==1
 bb=s.BoundingBox();report[name]={'valid':True,'solids':1,'faces':len(s.Faces()),'volume_mm3':s.Volume(),'size_mm':[bb.xlen,bb.ylen,bb.zlen],'roundtrip_volume_error_mm3':abs(s.Volume()-back.Volume())}
 cq.exporters.export(obj,str(P/'parts'/f'{name}-qa.stl'),tolerance=.015,angularTolerance=.08)
for name in ['base-S14','lid-S14']:assy.add(parts[name],name=name,color=cq.Color(.88,.9,.88))
for i,(x,y) in enumerate(keys):
 assy.add(cap,name=f'front_cap_{i+1}',loc=cq.Location(cq.Vector(x,y,22)),color=cq.Color(.95,.95,.92))
 assy.add(plug,name=f'front_carrier_{i+1}',loc=cq.Location(cq.Vector(x,y,22)),color=cq.Color(.86,.68,.3))
for i,y in enumerate([-40,40]):
 for name,obj in [('side_cap',side_cap)]:assy.add(obj,name=f'{name}_{i+1}',loc=cq.Location(cq.Vector(0,y,0)),color=cq.Color(.85,.62,.25) if name!='side_cap' else cq.Color(.3,.6,.7))
for i,(x,y) in enumerate(mounts):assy.add(bush,name=f'pcb_bush_{i+1}',loc=cq.Location(cq.Vector(x,y,4.2)))
assy.save(str(P/'dotBeats-S14-mechanical-assembly.step'))
report['assembly_solid_count']=len(cq.importers.importStep(str(P/'dotBeats-S14-mechanical-assembly.step')).val().Solids());assert report['assembly_solid_count']==19
(P/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

# Additional design-level checks.
checks={}
checks['base_lid_intersection_mm3']=base.val().intersect(lid.val()).Volume()
battery=cx(9.35,-26.65,26.65,by,bz)
checks['battery_base_intersection_mm3']=base.val().intersect(battery.val()).Volume()
checks['battery_lid_intersection_mm3']=lid.val().intersect(battery.val()).Volume()
for i,(x,y) in enumerate(keys):
 for stroke in [0,.4]:
  for name,obj in [('cap',cap),('carrier',plug)]:
   moved=obj.translate((x,y,22-stroke))
   checks[f'{name}{i}_lid_stroke{stroke}']=moved.val().intersect(lid.val()).Volume()
checks['cap_carrier_intersection_mm3']=cap.val().intersect(plug.val()).Volume()
(P/'clearance.json').write_text(json.dumps(checks,indent=2));print(checks)
assert max(checks.values())<1e-5,checks

# Explicit rear solder-access envelopes, including both photo-style rear pads
# and the previous outward tab extents. No plastic may cross these windows.
access={}
for cy in [-40,40]:
 for sign in [-1,1]:
  a,b=sorted([cy+sign*1.2,cy+sign*4.8])
  window=box(-34.1,-28.5,a,b,11.3,15)
  for name,obj in [('base',base),('lid',lid)]:
   access[f'{cy}_{sign}_{name}']=obj.val().intersect(window.val()).Volume()
assert max(access.values())<1e-5,access
(P/'solder-access.json').write_text(json.dumps(access,indent=2))
