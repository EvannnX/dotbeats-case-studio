from pathlib import Path
import trimesh,numpy as np,json
P=Path(__file__).parent;OFF=np.array([1.059492769,3,24]);s=trimesh.load(P.parent/'side_button_service_v1/assembly-S04.glb',force='scene');parts={}
def load(name):
 m=trimesh.load(P/'parts'/f'{name}-qa.stl');m.process(validate=True);return m
for n in s.graph.nodes_geometry:
 if n.startswith(('side_retainer','side_screw','side_nut','side_holder')):continue
 tf,g=s.graph[n];m=s.geometry[g].copy();m.apply_transform(tf);m.apply_scale(1000);m.apply_translation(OFF);m.merge_vertices();m.process(validate=True)
 if n=='base':m=load('base-S14')
 elif n=='lid':m=load('lid-S14')
 elif n.startswith(('cap_','plug_')):
  # Obtain the key centre from the original cap, independent of graph ordering.
  tf2,g2=s.graph['cap_'+n.split('_')[1]];c=s.geometry[g2].copy();c.apply_transform(tf2);xy=c.bounds.mean(axis=0)[:2]*1000+OFF[:2]
  m=load('front-cap-S14' if n.startswith('cap_') else 'front-carrier-S14');m.apply_translation([*xy,22])
 elif n.startswith(('motor_','wire_')):m.apply_translation([0,0,-2])
 elif n.startswith('side_holder'):
  m=load('side-holder-S14');m.apply_translation([0,-40 if n.endswith('_0') else 40,0])
 elif n=='battery':m.apply_translation([0,-2.7,-1.3])
 parts[n]=m
# Use the same front-PCB switch geometry, rotated to face the side opening.
for i,cy in enumerate([-40,40]):
 for source,target in [('switch_1','side_switch'),('actuator_1','side_actuator')]:
  m=parts[source].copy();m.apply_translation([22.690552951088,19.250044449961,-5.8000508])
  m.apply_transform(trimesh.transformations.rotation_matrix(-np.pi/2,[0,1,0]))
  m.apply_translation([-33.8,cy,13]);parts[f'{target}_{i}']=m
 leads=[]
 for sign in [-1,1]:
  q=trimesh.creation.box([.2,1.3,2.3]);q.apply_translation([-33.7,cy+sign*2.1,13]);leads.append(q)
 parts[f'side_leads_{i}']=trimesh.util.concatenate(leads)

out=trimesh.Scene()
for n,m in parts.items():
 a=m.copy();a.apply_scale(.001)
 if n in ['base','lid']:color=[223,229,223,255]
 elif n.startswith('cap_'):color=[235,240,230,255]
 elif n.startswith(('plug_','side_holder')):color=[231,170,70,255]
 else:color=None
 if color:a.visual=trimesh.visual.ColorVisuals(a,face_colors=color)
 out.add_geometry(a,node_name=n,geom_name=n)
out.export(P/'assembly-S14.glb')
checks={'component_collisions':[],'assembly_path_collisions':[]}
def vol(a,b):
 if not np.all(a.bounds[1]>b.bounds[0]) or not np.all(b.bounds[1]>a.bounds[0]):return 0
 if not b.is_volume:
  try:b=b.convex_hull
  except:return 0
 return abs(trimesh.boolean.intersection([a,b],check_volume=False).volume)
for n,a in parts.items():
 if n not in ['base','lid','battery'] and not n.startswith(('plug_','cap_','side_holder')):continue
 for k,b in parts.items():
  if not k.startswith(('STEP','carrier_original')):continue
  v=vol(a,b)
  if v>.005:checks['component_collisions'].append([n,k,v])
# Lid closes vertically; no board or side-switch body should obstruct its path.
for dz in np.arange(0,25,.5):
 a=parts['lid'].copy();a.apply_translation([0,0,dz])
 for k in ['base','battery','side_cap_0','side_cap_1','side_switch_0','side_switch_1','side_leads_0','side_leads_1','side_actuator_0','side_actuator_1']:
  v=vol(a,parts[k])
  if v>.005:checks['assembly_path_collisions'].append(['lid',float(dz),k,v])
for i in [0,1]:
 cap=parts[f'side_cap_{i}']
 for dz in np.arange(0,30.1,.5):
  a=cap.copy();a.apply_translation([0,0,dz]);v=vol(a,parts['base'])
  if v>.005:checks['assembly_path_collisions'].append(['cap lower',i,float(dz),v])
 for name in ['switch','actuator','leads']:
  for dz in np.arange(0,24.1,.5):
   a=parts[f'side_{name}_{i}'].copy();a.apply_translation([0,0,dz])
   for target in ['base',f'side_cap_{i}']:
    v=vol(a,parts[target])
    if v>.005:checks['assembly_path_collisions'].append([name,i,float(dz),target,v])
(P/'assembly-checks.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
