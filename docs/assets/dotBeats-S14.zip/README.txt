dotBeats S14 — Standard size / captured side switches

Envelope restored to 86.5 x140 x24 mm (excluding external button heads).
PCB/ESP/USB positions, corner fasteners and six front-button parts
are inherited unchanged from Standard S08. Side button spacing remains80 mm.
The unconfirmed front cap +3 mm / carrier -1 mm / slot5.5 mm edits are NOT applied.

SIDE SWITCH
The same reference geometry as the PCB tactile switch is rotated toward the side:
6x6 mm body, body depth3.5 mm, actuator diameter4.6 mm, total axial depth5 mm.
Two rear solder pads follow the supplied photograph as provisional representations;
exact pad positions and solder protrusions still need checking against the real part.
The integral cradle has a bottom seat, central backrest and front corner lips.
Backrest is1.8 mm wide and3 mm deep; rear pads remain exposed on both sides.
The cradle now has continuous 2 mm side walls, fused into the base.
The side walls leave 0.2 mm lateral clearance to the reference switch body.
Their rear ends stop before the solder access envelopes, leaving pads accessible.
The previous descending inner side guides are removed from the lid to clear these
walls. The integrated outer wrap frame remains; its top stop has 0.5 mm clearance
above the switch and 0.3 mm above the fixed side walls.
The lid stop bears on the body area, not the moving actuator. The front lips prevent
forward escape. No adhesive or additional screws are required for geometric capture.
Both rear access windows remain open with lid closed: each3.6 mm wide x3.7 mm
high, from X=-34.1 to-28.5. CAD clearance checks include both prior outward tabs
and photo-style rear pads. These are clearance envelopes, not iron/tool validation.

ASSEMBLY
1. With lid removed, lower external cap vertically into the side-wall top-entry slot.
2. Solder and insulate two wires on the switch while it is outside the case.
3. Lower switch vertically into cradle, actuator facing the cap; lead tabs and wires
   enter the two open channels. Do not force solder joints through narrow gaps.
4. Confirm seated body, free cap motion and no preload; route wires clear of PCB.
5. Lower lid. Outer frame surrounds the cradle; integrated stop limits lifting.
6. Close with existing case screws. Check free return before powering the electronics.

FILES
Mechanical STEP:19 solids, base/cradles one continuous solid. Electronic references
are in GLB, not STEP. Print-STL: base/lid x1; front cap/carrier x6; side cap x2;
PCB bushes x3. Optional local side coupons are for hand-held seam alignment tests.

VALIDATION
CAD validity, imported solid count, reference part clearance and sampled assembly
paths. Adhesive-free geometric capture is not a tested force or fatigue rating.
Actual switch size, solder joints, wire bend radii and FDM tolerance require a trial.
The narrower central backrest has no fatigue/force test; test the local coupon first.
Print the side coupons first. No claim that unmodeled wiring has been validated.
Preview http://127.0.0.1:5196/ . Previous versions preserved; not pushed to GitHub.

BATTERY UPDATE
Continuous lower-half cylindrical cradle replaces the two L brackets.
Battery reference remains diameter18.7 x53.3 mm, on the existing floor datum.
Cavity diameter19.3 mm, length53.9 mm; 0.3 mm nominal radial/end clearance.
Open top permits vertical insertion. Two 6 mm end notches provide lead clearance.
This supports the lower half; it is not a snap-fit or a verified wire restraint.
