def box(a,b,c,d,e,f):return cq.Workplane().box(b-a,d-c,f-e).translate(((a+b)/2,(c+d)/2,(e+f)/2))
# Seat remains integral with floor; no broad rear wall across terminal pads.
holder=box(-39,-34,-5.2,5.2,1.8,10)
holder=holder.union(box(-38,-30.6,-5.2,5.2,6.4,10))
# Central 1.8 mm wide x3 mm deep backrest leaves both rear pads exposed.
holder=holder.union(box(-33.6,-30.6,-.9,.9,9.9,16.2))
# Only front corner lips remain fixed. Side capture descends with lid.
for sign in [-1,1]:
 a,b=sorted([sign*2.65,sign*3.25])
 holder=holder.union(box(-38.3,-37.5,a,b,9.9,16.2))

# Continuous 2 mm side walls; rear terminal area remains open.
for sign in [-1,1]:
 a,b=sorted([sign*3.2,sign*5.2])
 holder=holder.union(box(-38.3,-34.4,a,b,9.9,16.2))
