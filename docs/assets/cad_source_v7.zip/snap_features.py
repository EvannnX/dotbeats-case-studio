"""FDM snap-fit prototype. Dimensions in mm; requires a fit trial."""
import cadquery as cq

def snap_dimensions(p):
 return dict(z=p['height']-p['lid'],inner=p['width']/2-p['wall'],outer=p['width']/2-p['wall']-p['fitClear'],ys=[-p['length']*.18,p['length']*.18])
def prism(points,y,width):
 # XZ workplane normal is -Y.
 return cq.Workplane('XZ',origin=(0,y+width/2,0)).polyline(points).close().extrude(width)
def add_snap_fit(base,lid,p):
 q=snap_dimensions(p);z=q['z'];d=p['clipDepth'];o=q['outer'];t=p['clipT'];bite=p['clipBite'];reach=p['fitClear']+bite
 def block(w,h,d,x,y,z):return cq.Workplane('XY').box(w,h,d).translate((x,y,z))
 def rounded(w,l,d,r,z):return cq.Workplane('XY',origin=(0,0,z)).box(w,l,d,centered=(True,True,False)).edges('|Z').fillet(r)
 w=p['width']-2*(p['wall']+p['fitClear']);l=p['length']-2*(p['wall']+p['fitClear']);rr=p['radius']-p['wall']-p['fitClear'];lt=1.2
 lip=rounded(w,l,p['lipDepth']+.05,rr,z-p['lipDepth']).cut(rounded(w-2*lt,l-2*lt,p['lipDepth']+.3,rr-lt,z-p['lipDepth']-.1))
 for sign in [-1,1]:
  for y in q['ys']:
   lip=lip.cut(block(5,8,p['lipDepth']+.4,sign*(o-1),y,z-p['lipDepth']/2))
   beam=[(o-t,z-d),(o,z-d),(o,z+.05),(o-t-.8,z+.05),(o-t,z-1.2)]
   hook=[(o-.1,z-d+.4),(o+reach,z-d+1.6),(o+reach,z-d+2.2),(o-.1,z-d+2.2)]
   for points in [beam,hook]:lid=lid.union(prism([(sign*x,a)for x,a in points],y,6))
   base=base.cut(block(p['wall']+2,6.8,2.2,sign*(p['width']/2-p['wall']/2),y,z-d+1.4))
  # Small landing pads stop the lid at the intended seam height.
  for y in [-p['length']*.38,p['length']*.38]:base=base.union(block(p['wall'],5,.35,sign*(p['width']/2-p['wall']/2),y,z-.175))
 lid=lid.union(lip)
 return base,lid
