dotBeats S03 — centered front keys

Six cap centres now lie at global X = -20, 0, +20 mm, Y = -22.5, +22.5 mm.
Outer enclosure remains 86.5 x 140 x 26 mm. Cap-head edge margins:
left/right = 15.35 mm each; top/bottom = 39.60 mm each.

WHAT CHANGED
Use the S03 lid, S03 keyed cap and S03 offset carrier as a matching set.
The visible caps and motors move +2.690515 X / -3.250001 Y mm.
Each vertical stem is offset -2.690515 X / +3.250001 Y relative to its cap.
It still lands on the ORIGINAL PCB switch centre.
An outer cap rib and matching lid slot prevent rotation. An inner cap key
and matching carrier groove index the carrier. Align the wire exit slots as well.
The PCB, ESP, all PCB mounting hardware, battery, USB port, side buttons and
base remain in their original S02 positions. The S03 base is identical to S02.
Moving the whole PCB was rejected because the ESP board would intersect the sidewall.

PRINT
1 lid-S03.stl
6 cap-S03.stl (head face down)
6 plug-S03.stl (carrier mating face down; stem up)
Reuse your S02 base, side buttons and PCB bushes, or print the included copies.
Do not mix original C01 caps/carriers with the S03 keyed lid.
STLs use millimetres. Front part Z values retain the original design datum;
place the intended face on the build plate in your slicer.

ASSEMBLY
Open assembly-guide.html for all ten steps and the hardware list.
Insert cap ribs into matching lid slots. Fit motors, align both wire exits,
then insert the keyed carriers and bond only the cap/carrier joint as before.
Do not glue sliding surfaces. Confirm all six stems point toward their switches.

VALIDATION
Exported printable meshes are watertight. Group-centre and stem-to-switch
axis errors are below 0.001 mm. Travel positions 0, 0.25 and 0.40 mm clear
both shell parts; checked against modeled electronic components as well.
See checks.json for results. Wire and actual solder envelopes remain unverified.
The offset load can affect friction and return: print ONE keyed button and test
smooth return and repeated presses before printing the full set.

LOCAL PREVIEW
http://127.0.0.1:5184/
Restart from site/: npm run dev -- --port 5184
Front orthographic view removes perspective distortion when checking centering.
Published at https://evannnx.github.io/dotbeats-case-studio/ . S02 is preserved separately.
