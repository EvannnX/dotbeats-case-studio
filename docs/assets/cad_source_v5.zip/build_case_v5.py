"""PREASSEMBLY: actual STEP models have incompatible socket row spacing.
Usage: python build_case_v5.py [parameters.json] --carrier full.step --esp DFR1222.stp
Requires cadquery. All dimensions in mm. Does not modify either input PCB.
"""
from pathlib import Path
import json,sys,math
import cadquery as cq
OUT=Path(__file__).resolve().parent
A=json.loads((OUT/'assembly_measurements.json').read_text())
P=json.loads((OUT/'defaults.json').read_text())['parameters']
args=sys.argv[1:];carrier_path=OUT/'3D_PCB1_2026-09-16.step';esp_path=OUT/'DFR1222.stp'
for flag in ['--carrier','--esp']:
 if flag in args:
  i=args.index(flag);v=args[i+1];del args[i:i+2]
  if flag=='--carrier':carrier_path=v
  else:esp_path=v
if args:
 data=json.loads(Path(args[0]).read_text());P.update(data.get('parameters',data))
p=P;w=p['width'];l=p['length'];t=p['wall'];h=p['height'];bh=h-p['lid']-.25
carrier_src=cq.importers.importStep(str(carrier_path)).val();esp_src=cq.importers.importStep(str(esp_path)).val()
def transform_carrier(s):return s.translate((-A['carrier_center'][0],-A['carrier_center'][1],0)).rotate((0,0,0),(0,0,1),90).translate((p['pcbX'],p['pcbY'],p['pcbZ']))
ep=[p['pcbX']+A['esp_local_origin'][0]+p['espX'],p['pcbY']+A['esp_local_origin'][1]+p['espY'],p['pcbZ']+A['esp_height_above_carrier']+p['espZ']]
def transform_esp(s):return s.rotate((0,0,0),(0,0,1),-90).translate(tuple(ep))
carrier=transform_carrier(carrier_src);esp=transform_esp(esp_src)
mounts=[(x+p['pcbX'],y+p['pcbY'])for x,y in A['mount_holes_local']]
buttons=[(p['pcbX']-3.750007620012+x+p['buttonX'],p['pcbY']+.25000127013+y+p['buttonY'])for y in [-p['buttonGapY']/2,p['buttonGapY']/2]for x in [-p['buttonGapX'],0,p['buttonGapX']]]
def box(w,l,d,r,z=0):return cq.Workplane('XY',origin=(0,0,z)).box(w,l,d,centered=(True,True,False)).edges('|Z').fillet(r)
base=box(w,l,bh,p['radius']).faces('<Z').edges().fillet(.6).cut(box(w-2*t,l-2*t,bh+2,p['radius']-t,p['floor']))
for y in [-p['sideGap']/2,p['sideGap']/2]:base=base.cut(cq.Workplane('YZ',origin=(-w/2-2,y,h/2)).circle((p['sideD']+.6)/2).extrude(t+4))
port=[-.06976233844,30.61500054,1.05351562325]
cut=box(9.00682486587+2*p['portClearance'],2.16096579007+2*p['portClearance'],t+4,1.4).rotate((0,0,0),(0,1,0),90).rotate((0,0,0),(1,0,0),90).translate((w/2-t-2,ep[1]-port[0],ep[2]+port[2]))
base=base.cut(cut)
for x,y in mounts:base=base.union(cq.Workplane('XY',origin=(x,y,p['floor']-.1)).circle(p['postD']/2).circle(p['pilotD']/2).extrude(p['pcbZ']-p['floor']+.1))
# Battery cradle inspired by the horizontal groove in VA Bot.stl. Body dimensions from user photo.
br=p['batteryD']/2+p['batteryClear'];bz=p['floor']+3+br;bl=p['batteryL']+4.8;bw=2*br+4;bx=p['batteryX'];by=p['batteryY']
holder=cq.Workplane('XY',origin=(bx,by,p['floor']-.1)).box(bl,bw,bz-p['floor']+.1,centered=(True,True,False))
void=cq.Workplane('YZ',origin=(bx-(p['batteryL']+.8)/2,by,bz)).circle(br).extrude(p['batteryL']+.8)
holder=holder.cut(void).cut(cq.Workplane('XY').box(3,7,5).translate((bx+bl/2-.5,by,bz)))
for x in [-p['batteryL']*.3,p['batteryL']*.3]:holder=holder.cut(cq.Workplane('XY').box(5.5,bw+2,1.5).translate((bx+x,by,p['floor']+1.25)))
base=base.union(holder)
battery=cq.Workplane('YZ',origin=(bx-p['batteryL']/2,by,bz)).circle(p['batteryD']/2).extrude(p['batteryL'])
lid=box(w,l,p['lid'],p['radius'],h-p['lid']).faces('>Z').edges().fillet(.6)
caps=[]
for x,y in buttons:
 lid=lid.cut(cq.Workplane('XY',origin=(x,y,h-p['lid']-1)).circle((p['buttonD']+.6)/2).extrude(p['lid']+2))
 caps.append(cq.Workplane('XY',origin=(x,y,h-.55)).circle(p['buttonD']/2).extrude(3.7).edges('>Z').fillet(.5))
for y in [-p['sideGap']/2,p['sideGap']/2]:caps.append(cq.Workplane('YZ',origin=(-w/2-2.9,y,h/2)).circle(p['sideD']/2).extrude(3.6))
pins=[];spacers=[]
for x,y in A['esp_pins']:pins.append(transform_esp(cq.Workplane('XY').box(.64,.64,7.8).translate((x,y,-3.5)).val()))
for sign in [-1,1]:
 row=[q for q in A['esp_pins']if (q[0]>0)==(sign>0)];ys=[q[1]for q in row]
 spacers.append(transform_esp(cq.Workplane('XY').box(2.5,max(ys)-min(ys)+2.54,2.5).translate((row[0][0],(max(ys)+min(ys))/2,-2.76)).val()))
assy=cq.Assembly(name='PCB1_ESP_PREASSEMBLY_SOCKET_MISMATCH')
for name,obj,color in [('enclosure_base',base,(.90,.90,.87)),('lid_with_switch_aligned_holes',lid,(.97,.97,.94)),('PCB1_original_STEP',carrier,(.03,.14,.35)),('DFR1222_original_STEP',esp,(.12,.24,.24)),('illustrative_male_pins_NOT_VALIDATED',cq.Compound.makeCompound(pins),(.74,.60,.32)),('illustrative_spacers_NOT_VALIDATED',cq.Compound.makeCompound(spacers),(.12,.12,.12))]:assy.add(obj,name=name,color=cq.Color(*color))
assy.add(battery,name='battery_envelope_18p7x53p3',color=cq.Color(.03,.48,.30))
for i,cap in enumerate(caps):assy.add(cap,name=f'button_visual_{i+1}',color=cq.Color(.97,.97,.94))
out=OUT/'exports';out.mkdir(exist_ok=True)
for name,obj in [('base_v5',base),('lid_v5',lid)]:
 assert obj.val().isValid()and len(obj.solids().vals())==1
 cq.exporters.export(obj,str(out/f'{name}.step'));cq.exporters.export(obj,str(out/f'{name}.stl'),tolerance=.03,angularTolerance=.1)
assy.save(str(out/'case_v5.step'))
# Exact intersections only for candidates that can touch the base. The mating defect is recorded separately.
collisions=[]
for family,source,transform in [('carrier',carrier_src,transform_carrier),('esp',esp_src,transform_esp)]:
 for i,so in enumerate(source.Solids()):
  obj=transform(so);b=obj.BoundingBox()
  outside_holder=(b.xmax<bx-bl/2 or b.xmin>bx+bl/2 or b.ymax<by-bw/2 or b.ymin>by+bw/2 or b.zmin>bz)
  if outside_holder and b.zmin>=p['pcbZ']-1e-6 and b.xmin>-w/2+t and b.xmax<w/2-t and b.ymin>-l/2+t and b.ymax<l/2-t:continue
  vol=base.val().intersect(obj).Volume()
  if vol>1e-5:collisions.append(dict(part=family,index=i,volume_mm3=vol))
headers=[transform_carrier(carrier_src.Solids()[i])for i in [1,120]]
pin_interference=sum(pin.intersect(head).Volume()for pin in pins for head in headers)
errors=[math.hypot(q['pin'][0]+p['espX']-q['socket'][0],q['pin'][1]+p['espY']-q['socket'][1])for q in A['pin_pairs_local']]
actual=[(x+p['pcbX'],y+p['pcbY'])for x,y,z in A['switches_local']]
button_error=max(min(math.hypot(x-a,y-b)for a,b in actual)for x,y in buttons)
report={'status':'PREASSEMBLY — SOCKET ROW SPACING DOES NOT MATCH','parameters':p,'carrier_holes_count':3,'carrier_hole_diameter_mm':5.20001016,'mount_axes_error_mm':0,'button_to_switch_max_error_mm':button_error,'socket_row_spacing_mm':A['socket_row_spacing'],'esp_row_spacing_mm':A['esp_row_spacing'],'row_spacing_difference_mm':A['socket_row_spacing']-A['esp_row_spacing'],'max_pin_center_error_mm':max(errors),'illustrative_pin_header_interference_mm3':pin_interference,'base_vs_original_boards_interference':collisions,'top_clearance_mm':h-p['lid']-(ep[2]+5.635),'bottom_clearance_mm':p['pcbZ']-1.59995-p['floor'],'usb_outer_recess_mm':w/2-ep[0]-port[1],'base_valid':base.val().isValid(),'lid_valid':lid.val().isValid(),'note':'Original carrier and ESP geometries preserved. Added male pins/spacers are illustrative. No manufacturability or electrical compatibility claim.'}
report['battery']={'body_diameter_mm':p['batteryD'],'overall_length_mm':p['batteryL'],'wire_envelope_mm':p['batteryWireD'],'cradle_internal_diameter_mm':2*br,'cradle_internal_length_mm':p['batteryL']+.8,'strap_slots_mm':[5.5,1.5],'cradle_to_pcb_gap_mm':p['pcbY']-A['carrier_size'][0]/2-(by+bw/2),'wire_to_lid_clearance_mm':h-p['lid']-(bz+p['batteryWireD']/2),'battery_base_intersection_mm3':base.val().intersect(battery.val()).Volume(),'battery_lid_intersection_mm3':lid.val().intersect(battery.val()).Volume()}
assert report['battery']['battery_base_intersection_mm3']<1e-5 and not collisions
(out/'validation_v5.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
