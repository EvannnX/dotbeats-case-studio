S04 SIDE-BUTTON SERVICEABLE TRIAL
STATUS: reference geometry, not physically verified. Actual user switch size is pending.
Do not print the full case until the coupon passes with your own switch.

CHANGED: use base-S04, separate side holders and retaining bridges together.
The previous fixed cradles are removed. S03 front lid/cap/carrier geometry is unchanged.
PRINT: base x1; lid x1; front cap and plug x6; PCB bush x3;
side cap x2; side holder x2; side bridge x2. First print coupon + one side set.
STL units mm. GLB units metres.

SIDE HARDWARE ONLY
4 x M2 x 18 mm machine screws, head diameter <=4 mm (length below head).
4 x M2 hex nuts, 4 mm across flats x 1.6 mm thick.
Reference switch 6 x 6 mm body, 3.4 mm body depth +0.9 mm actuator.
Pin and solder envelopes must be checked on your purchased part.
Old M2 x 6 self-tapping side screws are NOT used with this design.
Existing enclosure / PCB fasteners remain as S03.

INSTALL
1. Insert two nuts per module from the base underside; hold with removable tape.
2. Leave the holder OUT. Lower the cap 8 mm inward from its final position,
   then slide it horizontally outward through the side opening. Flange stays inside.
3. Lower the separate holder onto its low base seats, lining up both holes.
4. Lower the switch from above, head facing cap, terminals through open rear channels.
   Dry-fit first. Remove to solder and insulate, then check again with wires attached.
5. Lower the retaining bridge. Keep wires clear of its contact surfaces and holes.
6. Fit both M2 x18 screws into the underside nuts and tighten gently, alternately.
7. Check free return and electrical continuity. Repeat for second module.

PRINT
0.4 mm nozzle, 0.16-0.20 mm layers, 4 walls suggested.
Parts are supplied resting on the bed. Inspect sliced support requirements at nut
pockets, terminal reliefs and the horizontal shell hole; remove every support before fit.
Do not force a switch, flex its pins to fit, or glue the sliding cap.

VALIDATION
checks.json records sampled assembly paths (0.5 mm intervals), manifold meshes and
stationary component clearance. These do not establish real FDM tolerances, wiring
clearance, retention torque, switch overload or reliable return. Test with real hardware.
Installation animation: https://evannnx.github.io/dotbeats-case-studio/side.html
Published as an unverified reference trial. S03 has been preserved.
