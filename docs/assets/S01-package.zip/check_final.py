import trimesh,numpy as np,json
from pathlib import Path
p=Path(__file__).parent
b=trimesh.load(p/'parts/base-S01.stl');b.apply_translation([1.059492769,3,24])
s=trimesh.load(p/'assembly-S01.glb',force='scene');checks=json.loads((p/'checks.json').read_text())
for i in [0,1]:
 tf,g=s.graph[f'side_cap_{i}'];c=s.geometry[g].copy();c.apply_transform(tf);c.apply_scale(1000);c.apply_translation([1.059492769,3,24])
 for d in [0,.25,.5]:
  q=c.copy();q.apply_translation([d,0,0]);v=trimesh.boolean.intersection([q,b]).volume;checks[f'cap_{i}_base_intersection_{d}']=float(v);assert v<1e-4
clip=trimesh.creation.box(extents=[14,20,22],transform=trimesh.transformations.translation_matrix([-39,-40,11]))
coupon=trimesh.boolean.intersection([b,clip]);coupon.apply_translation(-coupon.bounds[0]);coupon.export(p/'parts/side-fit-coupon.stl');checks['coupon_watertight']=coupon.is_watertight
(p/'checks.json').write_text(json.dumps(checks,indent=2));print(checks)
