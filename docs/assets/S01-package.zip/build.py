from pathlib import Path
import cadquery as cq, trimesh, json, numpy as np
P=Path(__file__).parent; (P/'parts').mkdir(exist_ok=True)
offset=np.array([1.059492769,3,24])
def box(x0,x1,y0,y1,z0,z1):return cq.Workplane().box(x1-x0,y1-y0,z1-z0).translate(((x0+x1)/2,(y0+y1)/2,(z0+z1)/2))
def cx(r,x0,x1):return cq.Workplane('YZ').circle(r).extrude(x1-x0).translate((x0,0,13))
def hz(x,y,z,r,h):return cq.Workplane().circle(r).extrude(h).translate((x,y,z))
# Each cradle is printed as part of the base. Rear wall reacts the pressing force.
holder=box(-38,-34.4,-3.4,3.4,8.6,9.8).union(box(-34.5,-33.3,-3.4,3.4,9.7,15.5))
for s in [-1,1]:
 y0,y1=sorted([s*3.2,s*6.8])
 holder=holder.union(box(-39.55,-34.5,y0,y1,1.8,16.2))
 holder=holder.cut(hz(-37,s*5,10.2,.8,7))
for yy in [-2.25,2.25]: holder=holder.cut(box(-35,-33,yy-.8,yy+.8,9.3,10.25))
# 0.50 mm nominal hard-stop travel; sample-dependent switch pretravel must be checked.
cap=cx(6,-44.85,-41.25).union(cx(7.4,-41.25,-40.05)).union(cx(1.5,-40.05,-38.8))
bar=box(-39.4,-33.3,-6.8,6.8,16.2,18.2)
for s in [-1,1]:bar=bar.cut(hz(-37,s*5,16,1.1,3))
# Terminal escape slots above and below the body, open towards the PCB.
for y in [-2.25,2.25]:bar=bar.cut(box(-38,-33,y-.75,y+.75,16.1,17.1))
body=box(-37.9,-34.5,-3,3,10,16)
actuator=cx(1.75,-38.8,-37.9)
# Reference bent leads: representative envelopes, not a supplier-certified CAD model.
leads=None
for y in [-2.25,2.25]:
 for z in [9.75,16.25]:
  q=box(-35,-30.5,y-.35,y+.35,z-.15,z+.15)
  leads=q if leads is None else leads.union(q)
def mesh(shape):
 tmp=P/'tmp.stl';cq.exporters.export(shape,str(tmp),tolerance=.04,angularTolerance=.15);return trimesh.load(tmp,force='mesh')
meshes={k:mesh(v) for k,v in dict(holder=holder,cap=cap,retainer=bar,switch=body,actuator=actuator,leads=leads).items()}
for name in ['cap','retainer']:
 m=meshes[name].copy();
 if name=='cap':m.apply_transform(trimesh.transformations.rotation_matrix(-np.pi/2,[0,1,0]))
 m.apply_translation(-m.bounds[0]);m.export(P/'parts'/f'side-{name}-print-2.stl')
cq.exporters.export(cq.Compound.makeCompound([holder.val(),cap.val(),bar.val(),body.val(),leads.val()]),str(P/'side-button-module.step'))
base=trimesh.load(P.parent/'combined_design_v1/03_combined_C01_26mm/base-C01.stl');base.apply_translation(offset)
mods=[]
for y in [-40,40]:
 m=meshes['holder'].copy();m.apply_translation([0,y,0]);mods.append(m)
print([(m.is_watertight,m.volume,m.is_volume) for m in [base,*mods]]);newbase=trimesh.boolean.union([base,*mods],check_volume=False);newbase.apply_translation(-offset);newbase.export(P/'parts/base-S01.stl')
scene=trimesh.load(P.parent/'combined_design_v1/03_combined_C01_26mm/dotbeats-C01-assembled.glb',force='scene')
# Flatten old transforms into metres; preserve all detailed components except old placeholder side keys/base.
out=trimesh.Scene()
for n in scene.graph.nodes_geometry:
 tf,g=scene.graph[n]
 if n=='base' or n.startswith('sideKey'):continue
 m=scene.geometry[g].copy();m.apply_transform(tf);out.add_geometry(m,node_name=n,geom_name=n)
colors={'holder':[238,166,69,255],'cap':[88,166,181,255],'retainer':[238,166,69,255],'actuator':[205,205,190,255],'switch':[54,61,70,255],'leads':[190,190,195,255]}
b=newbase.copy();b.apply_scale(.001);b.visual=trimesh.visual.ColorVisuals(b,face_colors=[220,226,225,255]);out.add_geometry(b,node_name='base')
for i,y in enumerate([-40,40]):
 for name,m0 in meshes.items():
  if name=='holder':continue
  m=m0.copy();m.apply_translation(np.array([0,y,0])-offset);m.apply_scale(.001);m.visual=trimesh.visual.ColorVisuals(m,face_colors=colors[name]);out.add_geometry(m,node_name=f'side_{name}_{i}')
 for sy in [-5,5]:
  screw=hz(-37,y+sy,12.2,1,6).union(hz(-37,y+sy,18.2,1.8,1.3));m=mesh(screw);m.apply_translation(-offset);m.apply_scale(.001);m.visual=trimesh.visual.ColorVisuals(m,face_colors=[120,125,130,255]);out.add_geometry(m,node_name=f'side_screw_{i}_{sy}')
out.export(P/'assembly-S01.glb')
checks={'base_watertight':newbase.is_watertight,'base_bodies':len(newbase.split()),'centre_spacing_mm':80,'nominal_stop_mm':.5,'parts':{n:m.is_watertight for n,m in meshes.items()}}
for travel in [0,.25,.5]:
 c=meshes['cap'].copy();c.apply_translation([travel,0,0]);hit=trimesh.boolean.intersection([c,meshes['holder']]);checks[f'cap_holder_intersection_{travel}']=float(hit.volume)
# Check new stationary parts against real PCB geometry in common mm coordinates.
electronics=[]
for n in scene.graph.nodes_geometry:
 if any(k in n.lower() for k in ['carrier','esp','pcb','step_part']):
  tf,g=scene.graph[n];m=scene.geometry[g].copy();m.apply_transform(tf);m.apply_scale(1000);m.apply_translation(offset);electronics.append(m)
checks['electronics_meshes_examined']=len(electronics)
hits=[]
for y in [-40,40]:
 for name in ['holder','retainer','switch','leads','cap']:
  a=meshes[name].copy();a.apply_translation([0,y,0])
  for idx,b in enumerate(electronics):
   if np.all(a.bounds[1]>b.bounds[0]) and np.all(b.bounds[1]>a.bounds[0]):
    if b.is_volume:
     vol=trimesh.boolean.intersection([a,b]).volume
     if vol>1e-4:hits.append([y,name,idx,float(vol)])
    else:
     envelope=trimesh.creation.box(extents=b.extents,transform=trimesh.transformations.translation_matrix(b.bounds.mean(axis=0)))
     vol=trimesh.boolean.intersection([a,envelope]).volume
     if vol>1e-4:hits.append([y,name,idx,float(vol),'envelope'])
checks['electronics_collisions']=hits
(P/'checks.json').write_text(json.dumps(checks,indent=2));print(checks)
(P/'tmp.stl').unlink()
