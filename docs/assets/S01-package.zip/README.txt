S01 SIDE BUTTON PROTOTYPE
Existing C01 140 × 86.5 × 26 mm case; side switch centres 80 mm apart.

BUY
2 × 6 × 6 × 4.3 mm four-pin through-hole momentary normally-open tactile switches.
Reference: Omron B3F-1000 (100 gf nominal). Supplier substitutes MUST match the drawing.
Taobao search: 6x6x4.3 四脚 直插 轻触开关 常开 自复位 / 欧姆龙 B3F-1000
4 × M2 × 6 mm plastic self-tapping pan-head screws (head <= 4 mm).
Flexible hookup wire, insulation, solder. No additional heat-set inserts for these retainers.
Source: https://omronfs.omron.com/en_US/ecb/products/pdf/en-b3f.pdf
Availability of a specific Taobao seller is not verified.

PARTS
parts/base-S01.stl: replacement base, two cradles fused in. C01 assembly coordinates (mm).
parts/side-cap-print-2.stl: print two, face-down orientation provided.
parts/side-retainer-print-2.stl: print two, flat orientation provided.
side-button-module.step: editable one-button module geometry, original case coordinates.
assembly-S01.glb: complete assembly, metres. Purchased switch/lead/screw geometry is a reference envelope.
Original C01 lid and front buttons remain unchanged; copied into parts for convenience.

ASSEMBLY
Insert cap from inside before fitting switch. The inner flange prevents pull-out.
Wire and insulate switch; fit sideways into cradle with actuator toward cap.
Rear wall takes press load. Fit retainer and two screws, gently.
Route wires inward through lead escape slots, keeping them away from cap and battery.
Four-pin tact switches have two internally connected pairs: identify contacts using a meter.
Connect one contact from each pair to the intended input and common; no GPIO assignment is assumed.

PRINT / FIT
Suggested trial: 0.4 mm nozzle, 0.16–0.20 mm layers, 4 perimeters, PLA or PETG.
Base floor downward. Local supports may be needed under switch seat and horizontal side opening.
Remove supports and burrs completely. Do not lubricate or glue the sliding cap to the shell.
Cap Ø12 / shell bore Ø12.6: 0.30 mm radial clearance. Body seat nominal 6.4 mm wide.
Retainer pilot Ø1.6 mm: tune for actual screw and printer. Tightening must not distort switch body.
Nominal mechanical stop 0.50 mm. Reference pretravel 0.15–0.45 mm, not maximum permissible travel.
The actual switch and FDM tolerance stack must be tested; adjust cap tip and stop surfaces together.
No physical prototype, fatigue, return-force or wiring-clearance test has been performed.
Existing main PCB retention is outside this side-button change.

PREVIEW
From site/: npm run dev -- --port 5182
Open http://127.0.0.1:5182/ . All text in the viewer is English.
Published preview: https://evannnx.github.io/dotbeats-case-studio/

FIRST PRINT
Print side-fit-coupon.stl + one side cap + one retainer before printing the full base.
The coupon is a cropped sidewall/cradle section for checking fit, return and screw engagement.
